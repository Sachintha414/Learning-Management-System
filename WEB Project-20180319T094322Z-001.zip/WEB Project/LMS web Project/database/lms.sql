-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: July 28, 2017 at 11:48 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms`
--

-- --------------------------------------------------------

--
-- Table structure for table `alpost`
--

CREATE TABLE `alpost` (
  `postid` int(11) NOT NULL,
  `tittle` varchar(50) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `link` varchar(100) NOT NULL,
  `path` varchar(100) DEFAULT NULL,
  `subjectid` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alpost`
--

INSERT INTO `alpost` (`postid`, `tittle`, `description`, `link`, `path`, `subjectid`) VALUES
(1, 'AL Maths', 'Limit Introduction ', '', 'uploads/Details.txt', '1');

-- --------------------------------------------------------

--
-- Table structure for table `alsubject`
--

CREATE TABLE `alsubject` (
  `subjectid` int(11) NOT NULL,
  `subjectname` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alsubject`
--

INSERT INTO `alsubject` (`subjectid`, `subjectname`) VALUES
(1, 'INTRO (pure) '),
(2, 'Mathematics (Applied) '),
(3, 'BUSINESS'),
(4, 'ECON'),
(5, 'STATICA'),
(6, 'IT'),
(7, 'BUSINESS ii');

-- --------------------------------------------------------

--
-- Table structure for table `olpost`
--

CREATE TABLE `olpost` (
  `postid` int(11) NOT NULL,
  `tittle` varchar(50) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `link` varchar(100) NOT NULL,
  `path` varchar(100) DEFAULT NULL,
  `subjectid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `olpost`
--

INSERT INTO `olpost` (`postid`, `tittle`, `description`, `link`, `path`, `subjectid`) VALUES
(4, 'Science Easy2', 'Follow up the Youtube Channel for more', '', 'uploads/2.jpg', 2),
(8, 'Maths Easy', 'Follow the guides from Learn Online', '', 'uploads/sample.txt', 1);

-- --------------------------------------------------------

--
-- Table structure for table `olsubject`
--

CREATE TABLE `olsubject` (
  `subjectid` int(11) NOT NULL,
  `subjectname` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `olsubject`
--

INSERT INTO `olsubject` (`subjectid`, `subjectname`) VALUES
(1, 'INTRO'),
(2, 'JAVA'),
(3, 'ICT'),
(4, 'English');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `stdno` int(11) NOT NULL,
  `fname` varchar(15) DEFAULT NULL,
  `lname` varchar(15) NOT NULL,
  `sex` varchar(4) NOT NULL,
  `dob` date NOT NULL,
  `address1` varchar(15) DEFAULT NULL,
  `address2` varchar(15) NOT NULL,
  `city` varchar(15) NOT NULL,
  `role` varchar(10) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `password` varchar(6) DEFAULT NULL,
  `facid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`stdno`, `fname`, `lname`, `sex`, `dob`, `address1`, `address2`, `city`, `role`, `email`, `password`, `facid`) VALUES
(1, 'udara', 'prageeth', 'male', '1995-03-18', 'sasadsx', 'sxsaxsa', 'anuradhapura', 'student', 'abcd@gmail.com', 'abcd', 0),
(2, 'Kalhara', 'Rajapaksha', 'male', '0000-00-00', 'New Town', 'Dahaiyagama', 'Anuradhapura', 'student', 'kk@gmail.com', 'kk234', 0);

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `tid` int(11) NOT NULL,
  `tname` varchar(50) DEFAULT NULL,
  `role` varchar(10) DEFAULT NULL,
  `taddress` varchar(50) DEFAULT NULL,
  `temail` varchar(50) DEFAULT NULL,
  `tpassword` varchar(10) DEFAULT NULL,
  `ttel` varchar(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`tid`, `tname`, `role`, `taddress`, `temail`, `tpassword`, `ttel`) VALUES
(1, 'Kapila Siriwardane', 'teacher', 'colombo to', 'kapila@gmail.com', 'kapila', '701234567'),
(2, 'Asela Ranasinghe', 'teacher', 'kaluthara', 'asela@gmail.com', 'asela', '771234567');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alpost`
--
ALTER TABLE `alpost`
  ADD PRIMARY KEY (`postid`);

--
-- Indexes for table `alsubject`
--
ALTER TABLE `alsubject`
  ADD PRIMARY KEY (`subjectid`);

--
-- Indexes for table `olpost`
--
ALTER TABLE `olpost`
  ADD PRIMARY KEY (`postid`);

--
-- Indexes for table `olsubject`
--
ALTER TABLE `olsubject`
  ADD PRIMARY KEY (`subjectid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stdno`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`tid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alpost`
--
ALTER TABLE `alpost`
  MODIFY `postid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `alsubject`
--
ALTER TABLE `alsubject`
  MODIFY `subjectid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `olpost`
--
ALTER TABLE `olpost`
  MODIFY `postid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `olsubject`
--
ALTER TABLE `olsubject`
  MODIFY `subjectid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `stdno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
