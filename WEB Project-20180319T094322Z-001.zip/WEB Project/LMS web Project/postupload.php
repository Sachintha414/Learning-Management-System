<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body background="img/SignBack.jpg">
<br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
<div class="post">
<form action="">
<table border="0 px">
    <tr>
        <td>Tittle</td>
        <td><input type="text" name="tittle" id="tittle"> </td></tr>
    <tr>
        <td>Comment</td>
        <td><input type="text" name="comment" id="comment"></td></tr>
    <tr>
        <td>Description</td>
        <td><input type="text" name="descript" id="descript"></td></tr>
    <tr>
        <td>Video Link</td>
        <td><input type="text" name="link" id="link"></td></tr>
    <tr>
        <td>File 1 <br>File 2 <br>File 3</td>
        <td><input type="file" name="file1" id="file1"> <br>
            <input type="file" name="file2" id="file2"><br>
            <input type="file" name="file3" id="file3"></td></tr>
    <tr>
        <td colspan="2"><input type="submit" name="post" id="post" value="POST"></td></tr>
</table>
</form>
</div>

</body>
</html>