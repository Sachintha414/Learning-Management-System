<?php
session_start();
include 'include/islogin.php';
include 'functions/connection.php';
?>

<!doctype html>
<html lang="en">
<head>
    <?php include 'include/head.php'; ?>
</head>

<body background="img/SignBack.jpg">

<br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
<!--nav bar start-->
<?php
if ($_SESSION['role'] == "student") {
    include 'include/nav-bar(student).php';
} else if ($_SESSION['role'] == "teacher") {
    include 'include/nav-bar(teacher).php';
}
?>
<!--nav bar end-->
<div class="wrapper">
    <?php
    $sql = "SELECT `subjectname`,`subjectid` FROM `alsubject`";
    $result = mysqli_query($conn, $sql);
    foreach($result as $data){
        ?>
        <a href="alpost.php?subid=<?php echo $data['subjectid']; ?>" class="button"><?php echo $data['subjectname']; ?></a><br>
        <?php
        
    }
    ?>
</div>

<?php
include 'include/foot.php'
?>

</body>
</html>