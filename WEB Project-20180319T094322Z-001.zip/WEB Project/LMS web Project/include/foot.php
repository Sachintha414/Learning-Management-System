
<head>
        <link rel="stylesheet" href="./css/mainStyle.css">
    <link rel="stylesheet" href="./css/styleSlide.css">
</head>
<footer>
<p>Team Crypton Learning LAB, copyright &copy;2017 <br/>
                    
            <a href="">Follow Us On</a>
            <i class="fa fa-facebook-square" aria-hidden="true"></i> Facebook 
            <i class="fa fa-twitter-square" aria-hidden="true"></i> Twitter
            <i class="fa fa-linkedin-square" aria-hidden="true"></i> LinkedIn 
            <i class="fa fa-youtube-square" aria-hidden="true"></i> YouTube
</footer>
