<title>LearningLab</title>
<link rel="icon" href="img/plogo.png" type="image/png" sizes="16x16">
<link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <meta charset="UTF-8">
    <title>Document</title>



